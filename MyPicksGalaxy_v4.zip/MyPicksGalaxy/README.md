# MyPicksGalaxy

개인용 Android 앱 프로토타입. 공개 Wikimedia Commons 사진 후보를 보고 👍/👎 할 수 있으며 👍한 사진은 `Pictures/MyPicks`에 저장됩니다.

## 빌드
1. Android Studio에서 이 폴더를 Open 합니다.
2. JDK 17 / Android SDK 35를 사용합니다.
3. Gradle Sync 후 `Build > Build APK(s)`.
4. 생성된 APK를 갤럭시에 옮겨 직접 설치합니다.

## 비용/개인정보
- 서버 없음, 유료 AI/API 없음.
- 평가 기록은 SharedPreferences에 로컬 저장.
- 사진은 Wikimedia Commons API에서 가져옴. 각 사진의 실제 라이선스/출처는 Commons 원문 페이지에서 확인하세요.

## 안전 설계와 한계
- 검색은 `adult woman fashion portrait photograph`로 제한하고 노골적/미성년 관련 키워드를 제외합니다.
- 이미지에서 사람의 실제 나이를 정확히 판정하는 기능은 넣지 않았습니다. 검색 결과 메타데이터만으로 성인 여부를 완벽하게 보장할 수 없으므로, v1의 백그라운드 작업은 사용자가 이미 👍한 동일 URL만 자동 저장합니다.
- 얼굴 인식/신원 확인 기능은 없습니다.
- Wikimedia 검색 결과는 바뀔 수 있습니다.

## 진짜 '취향 자동 추천'으로 확장하려면
온디바이스 이미지 임베딩 모델(TFLite/ONNX)을 앱에 번들하고, 사용자가 평가한 임베딩의 평균 벡터로 후보를 점수화하면 됩니다. 모델 파일은 용량/라이선스가 다양하므로 이 프로젝트에는 임의의 제3자 모델 바이너리를 포함하지 않았습니다.
