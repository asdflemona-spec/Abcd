MyPicksGalaxy v3
- Adds a zero-cost, on-device conversational preference controller.
- Commands such as "새로운 스타일 탐색" or "내 취향과 비슷한 것 위주" switch recommendation mode locally.
- Existing thumbs up/down and private in-app storage remain.
- This build intentionally keeps collection to non-explicit adult-oriented fashion/glamour sources; it does not implement explicit pornography collection.
- No paid AI API is required.
