package com.example.mypicks
import android.content.Context
import java.io.File
object LibraryMeta {
    private fun sp(c: Context)=c.getSharedPreferences("library_tags",Context.MODE_PRIVATE)
    fun put(c:Context,f:File,tags:Set<String>)=sp(c).edit().putStringSet(f.name,tags).apply()
    fun tags(c:Context,f:File):Set<String> = sp(c).getStringSet(f.name, emptySet()) ?: emptySet()
    fun remove(c:Context,f:File){ sp(c).edit().remove(f.name).apply(); f.delete() }
}
