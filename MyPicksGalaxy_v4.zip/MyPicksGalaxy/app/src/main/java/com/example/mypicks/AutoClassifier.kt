package com.example.mypicks

object AutoClassifier {
    fun tags(c: Candidate): Set<String> {
        val s = (c.title + " " + c.pageUrl).lowercase()
        val out = linkedSetOf<String>()
        fun add(tag: String, vararg words: String) { if (words.any { s.contains(it) }) out += tag }
        add("수영복", "swimsuit", "swimwear", "bikini", "beachwear")
        add("글래머", "glamour", "glamor", "pin-up", "pinup")
        add("패션", "fashion", "model", "dress", "outfit")
        add("야외", "beach", "outdoor", "street", "park", "pool")
        add("스튜디오", "studio", "portrait")
        add("전신", "full body", "full-body", "standing")
        add("클로즈업", "close-up", "closeup", "headshot")
        if (out.isEmpty()) out += "기타"
        return out
    }
}
