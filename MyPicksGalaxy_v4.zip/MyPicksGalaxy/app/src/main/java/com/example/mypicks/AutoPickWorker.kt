package com.example.mypicks

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class AutoPickWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val prefs = Prefs(applicationContext)
        val candidates = runCatching { CommonsRepository.fetch(50) }.getOrElse { return Result.retry() }
        // Privacy-first v1: only previously-liked exact candidates are eligible for unattended saving.
        // This avoids pretending that age or attractiveness can be reliably inferred from a photo.
        var saved = 0
        for (c in candidates) {
            if (saved >= prefs.dailyLimit) break
            if (prefs.wasLiked(c.imageUrl) && !prefs.isSaved(c.imageUrl) && Downloader.save(applicationContext, c)) {
                prefs.markSaved(c.imageUrl); saved++
            }
        }
        return Result.success()
    }
}
