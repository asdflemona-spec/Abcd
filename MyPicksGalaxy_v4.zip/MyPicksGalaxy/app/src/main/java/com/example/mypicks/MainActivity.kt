package com.example.mypicks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.work.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); schedule(); setContent { MaterialTheme { App() } } }
    private fun schedule() {
        val c=Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto",ExistingPeriodicWorkPolicy.UPDATE,PeriodicWorkRequestBuilder<AutoPickWorker>(24,TimeUnit.HOURS).setConstraints(c).build())
    }
}

@Composable fun App() {
    val ctx=androidx.compose.ui.platform.LocalContext.current; val prefs=remember{Prefs(ctx)}; val engine=remember{PreferenceEngine(ctx)}; val scope=rememberCoroutineScope()
    var feed by remember{mutableStateOf<List<Candidate>>(emptyList())}; var idx by remember{mutableIntStateOf(0)}; var status by remember{mutableStateOf("불러오는 중…")}; var tab by remember{mutableIntStateOf(0)}
    var saved by remember{mutableStateOf(Downloader.savedFiles(ctx))}; var filter by remember{mutableStateOf("전체")}; var deleteTarget by remember{mutableStateOf<File?>(null)}
    fun load(){scope.launch{status="여러 소스에서 불러오는 중…"; val x=MultiSourceRepository.fetch(); feed=x.sortedByDescending{engine.score(it)}; idx=0; status=if(feed.isEmpty())"후보를 불러오지 못했습니다." else "${feed.size}개 후보 · Wikimedia + Openverse"}}
    LaunchedEffect(Unit){load()}
    Column(Modifier.fillMaxSize().padding(16.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Text("MyPicks V4",style=MaterialTheme.typography.headlineMedium); Text("자동 분류 · 자동 취향학습 · 앱 내부 저장",style=MaterialTheme.typography.bodySmall)
        TabRow(tab){Tab(tab==0,{tab=0},text={Text("추천")});Tab(tab==1,{saved=Downloader.savedFiles(ctx);tab=1},text={Text("보관함 (${saved.size})")})}
        Spacer(Modifier.height(8.dp))
        if(tab==0){
            val c=feed.getOrNull(idx)
            if(c!=null){
                var local by remember(c.imageUrl){mutableStateOf<File?>(null)}
                LaunchedEffect(c.imageUrl){local=Downloader.cache(ctx,c);if(local==null)status="이미지 다운로드 실패"}
                if(local!=null) AsyncImage(local,null,Modifier.fillMaxWidth().weight(1f),contentScale=ContentScale.Fit) else Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=Alignment.Center){CircularProgressIndicator()}
                Text("${c.source} · ${c.tags.joinToString(" · ")}",style=MaterialTheme.typography.bodySmall)
                Text(c.title,maxLines=1)
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly){
                    Button(onClick={prefs.rate(c.imageUrl,false);engine.learn(c.tags,false);idx++}){Text("👎")}
                    Button(onClick={scope.launch{prefs.rate(c.imageUrl,true);engine.learn(c.tags,true);if(Downloader.save(ctx,c)){prefs.markSaved(c.imageUrl);saved=Downloader.savedFiles(ctx);status="보관함 저장 · 자동 분류 완료"}else status="저장 실패";idx++}}){Text("👍 저장")}
                }
            } else {Spacer(Modifier.weight(1f));Button(onClick={load()}){Text("새 후보 불러오기")};Spacer(Modifier.weight(1f))}
            Text(status,style=MaterialTheme.typography.bodySmall)
        } else {
            val tags=(saved.flatMap{LibraryMeta.tags(ctx,it)}.distinct().sorted()); val visible=if(filter=="전체")saved else saved.filter{filter in LibraryMeta.tags(ctx,it)}
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(4.dp)){FilterChip(filter=="전체",{filter="전체"},{Text("전체")}); tags.take(3).forEach{t->FilterChip(filter==t,{filter=t},{Text(t)})}}
            if(visible.isEmpty()) Box(Modifier.weight(1f),contentAlignment=Alignment.Center){Text("해당 사진이 없습니다.")} else LazyColumn(Modifier.weight(1f).fillMaxWidth()){
                items(visible,key={it.absolutePath}){f->Column(Modifier.fillMaxWidth()){AsyncImage(f,null,Modifier.fillMaxWidth().height(390.dp),contentScale=ContentScale.Fit);Text(LibraryMeta.tags(ctx,f).joinToString(" · "),style=MaterialTheme.typography.bodySmall);TextButton(onClick={deleteTarget=f},modifier=Modifier.align(Alignment.End)){Text("삭제")};HorizontalDivider()}}
            }
        }
    }
    deleteTarget?.let{f->AlertDialog(onDismissRequest={deleteTarget=null},title={Text("사진 삭제")},text={Text("앱 보관함에서 이 사진을 삭제할까요?")},confirmButton={TextButton(onClick={LibraryMeta.remove(ctx,f);saved=Downloader.savedFiles(ctx);deleteTarget=null}){Text("삭제")}},dismissButton={TextButton(onClick={deleteTarget=null}){Text("취소")}})}
}
