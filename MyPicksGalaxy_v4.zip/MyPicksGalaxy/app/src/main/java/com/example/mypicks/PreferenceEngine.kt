package com.example.mypicks

import android.content.Context

class PreferenceEngine(context: Context) {
    private val sp = context.getSharedPreferences("auto_rank", Context.MODE_PRIVATE)
    private fun key(tag: String) = "w_$tag"
    fun weight(tag: String): Int = sp.getInt(key(tag), 0)
    fun learn(tags: Set<String>, liked: Boolean) {
        val e = sp.edit()
        tags.forEach { tag -> e.putInt(key(tag), (weight(tag) + if (liked) 2 else -1).coerceIn(-20, 40)) }
        e.apply()
    }
    fun score(c: Candidate): Int = c.tags.sumOf { weight(it) }
}
