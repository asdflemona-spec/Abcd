package com.example.mypicks

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

object MultiSourceRepository {
    private val client = OkHttpClient()
    private val blocked = listOf("nude", "nudity", "porn", "explicit", "sex act", "genital", "underage", "teen", "child", "girl", "boy")
    private val queries = listOf("adult woman swimwear fashion", "adult woman glamour fashion", "adult woman portrait fashion")

    suspend fun fetch(): List<Candidate> = coroutineScope {
        val commons = async { runCatching { fetchCommons() }.getOrDefault(emptyList()) }
        val openverse = async { runCatching { fetchOpenverse() }.getOrDefault(emptyList()) }
        (commons.await() + openverse.await()).distinctBy { it.imageUrl }.shuffled()
    }

    private suspend fun fetchCommons(): List<Candidate> = withContext(Dispatchers.IO) {
        val all = mutableListOf<Candidate>()
        for (query in queries) {
            val q = URLEncoder.encode(query, "UTF-8")
            val url = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=12&prop=imageinfo|info&iiprop=url&iiurlwidth=1200&inprop=url&format=json&origin=*"
            val req = Request.Builder().url(url).header("User-Agent", "MyPicksGalaxy/4.0 personal-use").build()
            val body = client.newCall(req).execute().use { if (!it.isSuccessful) return@use ""; it.body?.string().orEmpty() }
            if (body.isBlank()) continue
            val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: continue
            pages.keys().forEach { key ->
                val p = pages.getJSONObject(key); val title = p.optString("title"); val low = title.lowercase()
                if (blocked.any { low.contains(it) }) return@forEach
                val ii = p.optJSONArray("imageinfo")?.optJSONObject(0) ?: return@forEach
                val image = ii.optString("thumburl", ii.optString("url")); val page = p.optString("fullurl")
                if (image.startsWith("https://")) { val c = Candidate(title,image,page,"Wikimedia"); all += c.copy(tags=AutoClassifier.tags(c)) }
            }
        }
        all
    }

    private suspend fun fetchOpenverse(): List<Candidate> = withContext(Dispatchers.IO) {
        val all = mutableListOf<Candidate>()
        for (query in queries) {
            val q = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.openverse.org/v1/images/?q=$q&page_size=20&mature=false"
            val req = Request.Builder().url(url).header("User-Agent", "MyPicksGalaxy/4.0 personal-use").build()
            val body = client.newCall(req).execute().use { if (!it.isSuccessful) return@use ""; it.body?.string().orEmpty() }
            if (body.isBlank()) continue
            val arr = JSONObject(body).optJSONArray("results") ?: continue
            for (i in 0 until arr.length()) {
                val o=arr.getJSONObject(i); val title=o.optString("title","Openverse image"); val low=title.lowercase()
                if (blocked.any { low.contains(it) }) continue
                val image=o.optString("thumbnail", o.optString("url")); val page=o.optString("foreign_landing_url", o.optString("detail_url"))
                if (image.startsWith("https://")) { val c=Candidate(title,image,page,"Openverse"); all += c.copy(tags=AutoClassifier.tags(c)) }
            }
        }
        all
    }
}
