package com.example.mypicks

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.work.*
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        schedule()
        setContent { MaterialTheme { App() } }
    }
    private fun schedule() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val req = PeriodicWorkRequestBuilder<AutoPickWorker>(24, TimeUnit.HOURS).setConstraints(constraints).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("auto", ExistingPeriodicWorkPolicy.UPDATE, req)
    }
}

@Composable fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf<List<Candidate>>(emptyList()) }
    var idx by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("불러오는 중…") }
    var tab by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(Downloader.savedFiles(ctx)) }

    fun load() { scope.launch { status="불러오는 중…"; items = runCatching { CommonsRepository.fetch() }.getOrDefault(emptyList()); idx=0; status=if(items.isEmpty()) "후보를 불러오지 못했습니다." else "${items.size}개 후보" } }
    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("MyPicks", style = MaterialTheme.typography.headlineMedium)
        Text("모바일 데이터 지원 · 사진은 앱 내부에만 저장", style = MaterialTheme.typography.bodySmall)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab==0, onClick={tab=0}, text={Text("추천")})
            Tab(selected = tab==1, onClick={saved=Downloader.savedFiles(ctx); tab=1}, text={Text("보관함 (${saved.size})")})
        }
        Spacer(Modifier.height(8.dp))
        if (tab == 0) {
            val c = items.getOrNull(idx)
            if (c != null) {
                var local by remember(c.imageUrl) { mutableStateOf<File?>(null) }
                LaunchedEffect(c.imageUrl) {
                    local = Downloader.cache(ctx, c)
                    if (local == null) status = "이미지 다운로드 실패"
                }
                if (local != null) {
                    AsyncImage(model=local, contentDescription=c.title, modifier=Modifier.fillMaxWidth().weight(1f), contentScale=ContentScale.Fit)
                } else {
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) { CircularProgressIndicator() }
                }
                Text(c.title, maxLines=1)
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                    Button(onClick={ prefs.rate(c.imageUrl,false); idx=(idx+1).coerceAtMost(items.size) }) { Text("👎") }
                    Button(onClick={ scope.launch { prefs.rate(c.imageUrl,true); if (Downloader.save(ctx,c)) { prefs.markSaved(c.imageUrl); saved=Downloader.savedFiles(ctx); status="앱 보관함에 저장됨" } else status="저장 실패"; idx=(idx+1).coerceAtMost(items.size) } }) { Text("👍 저장") }
                }
            } else {
                Spacer(Modifier.weight(1f)); Button(onClick={load()}) { Text("새 후보 불러오기") }; Spacer(Modifier.weight(1f))
            }
            Text("$status · 하루 최대 ${prefs.dailyLimit}장", style=MaterialTheme.typography.bodySmall)
        } else {
            if (saved.isEmpty()) Box(Modifier.weight(1f), contentAlignment=Alignment.Center) { Text("저장된 사진이 없습니다.") }
            else LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                items(saved, key={it.absolutePath}) { f ->
                    AsyncImage(model=f, contentDescription=null, modifier=Modifier.fillMaxWidth().height(420.dp).padding(vertical=4.dp), contentScale=ContentScale.Fit)
                }
            }
        }
    }
}
