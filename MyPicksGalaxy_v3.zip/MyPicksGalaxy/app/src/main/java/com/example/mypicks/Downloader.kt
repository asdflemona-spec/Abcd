package com.example.mypicks

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest

object Downloader {
    private val client = OkHttpClient()
    private const val UA = "MyPicksGalaxy/2.0 (personal Android app)"

    private fun name(url: String): String = MessageDigest.getInstance("SHA-256")
        .digest(url.toByteArray()).joinToString("") { "%02x".format(it) } + ".img"

    suspend fun cache(context: Context, c: Candidate): File? = withContext(Dispatchers.IO) {
        runCatching {
            val dir = File(context.cacheDir, "images").apply { mkdirs() }
            val file = File(dir, name(c.imageUrl))
            if (file.exists() && file.length() > 0) return@runCatching file
            val req = Request.Builder().url(c.imageUrl).header("User-Agent", UA).header("Accept", "image/*").build()
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) error("HTTP ${r.code}")
                val body = r.body ?: error("empty body")
                file.outputStream().use { out -> body.byteStream().use { it.copyTo(out) } }
            }
            file
        }.getOrNull()
    }

    suspend fun save(context: Context, c: Candidate): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val src = cache(context, c) ?: error("download failed")
            val dir = File(context.filesDir, "saved").apply { mkdirs() }
            val dst = File(dir, name(c.imageUrl))
            src.copyTo(dst, overwrite = true)
            true
        }.getOrDefault(false)
    }

    fun savedFiles(context: Context): List<File> =
        File(context.filesDir, "saved").listFiles()?.filter { it.isFile && it.length() > 0 }
            ?.sortedByDescending { it.lastModified() } ?: emptyList()
}
