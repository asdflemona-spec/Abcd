package com.example.mypicks

import android.content.Context

/** Lightweight, free, on-device preference controller. No cloud AI/API required. */
class PreferenceEngine(context: Context) {
    private val sp = context.getSharedPreferences("ai_prefs", Context.MODE_PRIVATE)

    fun interpret(text: String): String {
        val t = text.trim().lowercase()
        if (t.isBlank()) return "명령을 입력해 주세요."
        val mode = when {
            listOf("새로운", "탐색", "다양").any { t.contains(it) } -> "explore"
            listOf("취향", "비슷", "확실").any { t.contains(it) } -> "similar"
            else -> sp.getString("mode", "balanced") ?: "balanced"
        }
        sp.edit().putString("mode", mode).putString("last_prompt", text).apply()
        return when (mode) {
            "explore" -> "탐색 모드: 다양한 비노골적 성인 패션/화보 후보를 섞습니다."
            "similar" -> "취향 우선 모드: 좋아요 기록을 더 강하게 반영합니다."
            else -> "균형 모드로 저장했습니다: $text"
        }
    }

    fun modeLabel(): String = when (sp.getString("mode", "balanced")) {
        "explore" -> "탐색"
        "similar" -> "취향 우선"
        else -> "균형"
    }
}
