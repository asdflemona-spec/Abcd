package com.example.mypicks

data class Candidate(val title: String, val imageUrl: String, val pageUrl: String)
